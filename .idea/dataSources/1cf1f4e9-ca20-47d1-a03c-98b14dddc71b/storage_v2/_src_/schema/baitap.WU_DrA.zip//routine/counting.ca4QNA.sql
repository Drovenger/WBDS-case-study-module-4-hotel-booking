create
    definer = root@localhost procedure counting(IN number int)
begin
    (select
        CASE
        when number = 1 then 'Mot'
        when number = 2 then 'Hai'
        when number = 3 then 'Ba'
        when number = 4 then 'Bon'
        when number = 5 then 'Nam'
        when number = 6 then 'Sau'
        when number = 7 then 'Bay'
        when number = 8 then 'Tam'
        when number = 9 then 'Chin'
        else 'Tinh nang dang phat trien'
    end as message);
end;


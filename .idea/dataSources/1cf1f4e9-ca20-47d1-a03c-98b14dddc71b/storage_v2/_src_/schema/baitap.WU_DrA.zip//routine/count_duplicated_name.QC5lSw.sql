create
    definer = root@localhost procedure count_duplicated_name()
begin
    select name, count(*) occurrences from students group by name having count(*) >= 2;
end;


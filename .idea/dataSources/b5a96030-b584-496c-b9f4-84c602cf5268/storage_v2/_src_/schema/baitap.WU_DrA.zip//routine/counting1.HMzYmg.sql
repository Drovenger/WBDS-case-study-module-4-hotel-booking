create
    definer = root@localhost procedure counting1(IN number int, OUT return1 varchar(255))
begin
    case number
        when 0 then set return1 = 'Khong';
        when 1 then set return1 = 'Mot';
        when 2 then set return1 = 'Hai';
        when 3 then set return1 = 'Ba';
        when 4 then set return1 = 'Bon';
        when 5 then set return1 = 'Nam';
        when 6 then set return1 = 'Sau';
        when 7 then set return1 = 'Bay';
        when 8 then set return1 = 'Tam';
        when 9 then set return1 = 'Chin';
        else set return1 = 'Khong co';
        end case;
end;


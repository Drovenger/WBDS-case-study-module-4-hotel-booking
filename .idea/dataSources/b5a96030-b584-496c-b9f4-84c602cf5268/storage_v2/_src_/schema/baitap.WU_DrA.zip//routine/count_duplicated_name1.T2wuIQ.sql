create
    definer = root@localhost procedure count_duplicated_name1()
begin
    DECLARE done INT DEFAULT 0;
    declare v_count int;
    declare v_name nvarchar(255);
    declare list_student cursor for select count(*), name from students group by name;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;
    open list_student;
    loop0 :
    LOOP
        FETCH list_student INTO v_count, v_name;
        IF done = 1 THEN
            LEAVE loop0;
        END IF;
        if v_count > 1 then
            insert into test values (v_name, v_count);
        end if;
    END LOOP loop0;
    close list_student;
end;


create
    definer = root@localhost procedure update_student()
begin
    DECLARE done INT DEFAULT 0;
    declare v_address nvarchar(255);
    declare list_student cursor for select address from students where name = 'Vinh';
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;
    open list_student;
    loop0 : LOOP
        FETCH list_student INTO v_address;
        IF done = 1 THEN
            LEAVE loop0;
        END IF;
        update students set age = 10 where address = v_address;
    END LOOP loop0;
    close list_student;
end;

